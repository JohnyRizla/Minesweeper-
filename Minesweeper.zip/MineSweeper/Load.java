import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.awt.event.*;

/**
 * <h1>Load Game</h1>
 * Load class creates a popUp Window that we give an appropriate number x 
 * for loading the SCENARIO-ID[x] through a TextField and with the Submit button we load it
 * 
 * */
public class Load implements ActionListener{
	private static boolean load = false;
	private static String ScenarioID, title;

	private String pathS, pathE;
	private JFrame frame;
	private JPanel pane;
	private JButton button;
	private JLabel l_x;
	private JTextField f_x;
	private int f_x_value;


	public Load(){
		pathS = "C:/Users/John/Desktop/MineSweeper/input/SCENARIO-ID[";
		pathE = "].txt";
		title = "Load Game";
		frame = new JFrame(title);
		frame.setPreferredSize(new Dimension((int)(Game.getWidth()/3),(int)(Game.getHeight()/4)));
        frame.setMinimumSize(new Dimension((int)(Game.getWidth()/3),(int)(Game.getHeight()/4)));
        frame.setMaximumSize(new Dimension((int)(Game.getWidth()/3),(int)(Game.getHeight()/4)));
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setTitle(title);
        frame.setFont(new Font("Courier", Font.BOLD,100));
        frame.setFont(frame.getFont().deriveFont(10f)); 

        l_x = new JLabel("Give number X for : Scenario-ID[X]");
        f_x = new JTextField(2);

        button = new JButton("Load");
        button.addActionListener(this);

        pane = new JPanel();
        pane.setLayout(new BoxLayout(pane, BoxLayout.Y_AXIS));

        pane.add(l_x); pane.add(f_x);
        pane.add(button);
        frame.add(pane);
        frame.setContentPane(pane);
        frame.pack();
        frame.setVisible(true);

        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                        // Ask for confirmation before terminating the program.
                int option = JOptionPane.showConfirmDialog(
                    frame, 
                    "Are you sure you want to close the window?",
                    "Close Confirmation", 
                    JOptionPane.YES_NO_OPTION, 
                    JOptionPane.QUESTION_MESSAGE);
                if (option == JOptionPane.YES_OPTION) {
                    frame.dispose();
                }
            }
        });
	}

	public void actionPerformed(ActionEvent ae){
    	f_x_value = Integer.valueOf(f_x.getText());
        if(ae.getSource() == button){
        	File file = new File(pathS + String.valueOf(f_x_value) + pathE);
        	if(file.isFile()){
        		load = true;
        		ScenarioID = String.valueOf(f_x_value);
        		frame.dispose();
        	}else{
        		pane = new JPanel();
        		pane.setLayout(new BoxLayout(pane, BoxLayout.Y_AXIS));
        		pane.add(new JLabel("<html><font color='red'>Please give existed X for Scenario-ID[X] !</font></html>"));
           		pane.add(f_x); pane.add(button);
           		frame.add(pane);
           		frame.revalidate();
	            frame.repaint();
           		frame.setContentPane(pane);
        		frame.pack();
        		//frame.setVisible(true);
	          
        	}  
        }
      
   }

   /**
    * Setes and getes for the MenuBar: the Start button
    * */
	public static boolean getLoaded(){
		return load;
	}
	public static String getScenarioID(){
		return ScenarioID;
	}

    /**
     * The main method is here for testing and it doesn't do anything*/
	public static void main(String... args){
		new Load();
	}
}