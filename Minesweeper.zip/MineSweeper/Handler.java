import java.util.ArrayList;

/**
 * <h1>Handler</h1>
 * Handler methods are the most significant things in all the program. 
 * Through the MouseListener from the Cell class, they are called and do all the essential computations of the Game
 * @param queue is an ArrayList that takes all the neighbours of a Cell that is being clicked
 * @param current is an ArrayList of Cells that purifies the queue list
 *  <p>
 * We use all lot setes and getes from other classes as Game, Grid or Cell
 * Always we call the ClockPane.ticktok() that refresh the live tracking parameters of the Game 
 * */

public class Handler {

    private ArrayList<Cell> current = new ArrayList<Cell>();
    private ArrayList<Cell> queue = new ArrayList<Cell>();
    
    public void click(Cell cell) {
        if(!Game.getWin() && !Game.getLose()){
            int discoveredCells = 0;
            if(!cell.isFlagged()) {
                cell.setEnabled(false);
                cell.setDiscovered(true);
                int position = cell.getPosition();
                if(cell.getType() == 0) {
                    if(position < Game.getGridsize()) {
                        if(position % Game.getGridsize() == 0) {
                            queue.add(Grid.getcellGrid().get((position + Game.getGridsize())));
                            queue.add(Grid.getcellGrid().get((position + Game.getGridsize() + 1)));
                            queue.add(Grid.getcellGrid().get((position + 1)));
                        } else if(position % Game.getGridsize() == Game.getGridsize() - 1) {
                            queue.add(Grid.getcellGrid().get((position + Game.getGridsize())));
                            queue.add(Grid.getcellGrid().get((position + Game.getGridsize() - 1)));
                            queue.add(Grid.getcellGrid().get((position - 1)));
                        } else {
                            queue.add(Grid.getcellGrid().get((position + Game.getGridsize())));
                            queue.add(Grid.getcellGrid().get((position + Game.getGridsize() + 1)));
                            queue.add(Grid.getcellGrid().get((position + Game.getGridsize() - 1)));
                            queue.add(Grid.getcellGrid().get((position + 1)));
                            queue.add(Grid.getcellGrid().get((position - 1)));
                        }
                    } else if(position >= (Game.getGridsize() * (Game.getGridsize() - 1))) {
                        if(position % Game.getGridsize() == 0) {
                            queue.add(Grid.getcellGrid().get((position - Game.getGridsize())));
                            queue.add(Grid.getcellGrid().get((position - Game.getGridsize() + 1)));
                            queue.add(Grid.getcellGrid().get((position + 1)));
                        } else if(position % Game.getGridsize() == Game.getGridsize() - 1) {
                            queue.add(Grid.getcellGrid().get((position - Game.getGridsize())));
                            queue.add(Grid.getcellGrid().get((position - Game.getGridsize() - 1)));
                            queue.add(Grid.getcellGrid().get((position - 1)));
                        } else {
                            queue.add(Grid.getcellGrid().get((position - Game.getGridsize())));
                            queue.add(Grid.getcellGrid().get((position - Game.getGridsize() + 1)));
                            queue.add(Grid.getcellGrid().get((position - Game.getGridsize() - 1)));
                            queue.add(Grid.getcellGrid().get((position + 1)));
                            queue.add(Grid.getcellGrid().get((position - 1)));
                        }
                    } else if(position % Game.getGridsize() == 0) {
                        queue.add(Grid.getcellGrid().get((position - Game.getGridsize())));
                        queue.add(Grid.getcellGrid().get((position + Game.getGridsize())));
                        queue.add(Grid.getcellGrid().get((position - Game.getGridsize() + 1)));
                        queue.add(Grid.getcellGrid().get((position + Game.getGridsize() + 1)));
                        queue.add(Grid.getcellGrid().get((position + 1)));
                    } else if(position % Game.getGridsize() == Game.getGridsize() - 1) {
                        queue.add(Grid.getcellGrid().get((position - Game.getGridsize())));
                        queue.add(Grid.getcellGrid().get((position + Game.getGridsize())));
                        queue.add(Grid.getcellGrid().get((position - Game.getGridsize() - 1)));
                        queue.add(Grid.getcellGrid().get((position + Game.getGridsize() - 1)));
                        queue.add(Grid.getcellGrid().get((position - 1)));
                    } else {
                        queue.add(Grid.getcellGrid().get((position - Game.getGridsize())));
                        queue.add(Grid.getcellGrid().get((position + Game.getGridsize())));
                        queue.add(Grid.getcellGrid().get((position - Game.getGridsize() - 1)));
                        queue.add(Grid.getcellGrid().get((position + Game.getGridsize() - 1)));
                        queue.add(Grid.getcellGrid().get((position - Game.getGridsize() + 1)));
                        queue.add(Grid.getcellGrid().get((position + Game.getGridsize() + 1)));
                        queue.add(Grid.getcellGrid().get((position - 1)));
                        queue.add(Grid.getcellGrid().get((position + 1)));
                    }
                } 
                else if(cell.getType() == 2) {
                    int dangerCount = 0;
                    if(position < Game.getGridsize()) {
                        if(position % Game.getGridsize() == 0) {
                            if(Grid.getcellGrid().get(position + Game.getGridsize()).isMine()) dangerCount++;
                            if(Grid.getcellGrid().get(position + Game.getGridsize() + 1).isMine()) dangerCount++; 
                            if(Grid.getcellGrid().get(position + 1).isMine()) dangerCount++;
                        } else if(position % Game.getGridsize() == Game.getGridsize() - 1) {
                            if(Grid.getcellGrid().get(position + Game.getGridsize()).isMine()) dangerCount++;
                            if(Grid.getcellGrid().get(position + Game.getGridsize() - 1).isMine()) dangerCount++;
                            if(Grid.getcellGrid().get(position - 1).isMine()) dangerCount++;
                        } else {
                            if(Grid.getcellGrid().get(position + Game.getGridsize()).isMine()) dangerCount++;
                            if(Grid.getcellGrid().get(position + Game.getGridsize() + 1).isMine()) dangerCount++;
                            if(Grid.getcellGrid().get(position + Game.getGridsize() - 1).isMine()) dangerCount++;
                            if(Grid.getcellGrid().get(position + 1).isMine()) dangerCount++;
                            if(Grid.getcellGrid().get(position - 1).isMine()) dangerCount++;
                            System.out.println(dangerCount);
                        }
                    } else if(position >= (Game.getGridsize() * (Game.getGridsize() - 1))) {
                        if(position % Game.getGridsize() == 0) {
                            if(Grid.getcellGrid().get(position - Game.getGridsize()).isMine()) dangerCount++;
                            if(Grid.getcellGrid().get(position - Game.getGridsize() + 1).isMine()) dangerCount++;
                            if(Grid.getcellGrid().get(position + 1).getType() == 1) dangerCount++;
                        } else if(position % Game.getGridsize() == Game.getGridsize() - 1) {
                            if(Grid.getcellGrid().get(position - Game.getGridsize()).isMine()) dangerCount++;
                            if(Grid.getcellGrid().get(position - Game.getGridsize() - 1).isMine()) dangerCount++;
                            if(Grid.getcellGrid().get(position - 1).isMine()) dangerCount++;
                        } else {
                            if(Grid.getcellGrid().get(position - Game.getGridsize()).isMine()) dangerCount++;
                            if(Grid.getcellGrid().get(position - Game.getGridsize()+ 1).isMine()) dangerCount++;
                            if(Grid.getcellGrid().get(position - Game.getGridsize() - 1).isMine()) dangerCount++;
                            if(Grid.getcellGrid().get(position + 1).isMine()) dangerCount++;
                            if(Grid.getcellGrid().get(position - 1).isMine()) dangerCount++;
                        }
                    } else if(position % Game.getGridsize() == 0) {
                        if(Grid.getcellGrid().get(position - Game.getGridsize()).isMine()) dangerCount++;
                        if(Grid.getcellGrid().get(position + Game.getGridsize()).isMine()) dangerCount++;
                        if(Grid.getcellGrid().get(position - Game.getGridsize() + 1).isMine()) dangerCount++;
                        if(Grid.getcellGrid().get(position + Game.getGridsize() + 1).isMine()) dangerCount++;
                        if(Grid.getcellGrid().get(position + 1).isMine()) dangerCount++;
                    } else if(position % Game.getGridsize() == Game.getGridsize() - 1) {
                        if(Grid.getcellGrid().get((position - Game.getGridsize())).isMine()) dangerCount++;
                        if(Grid.getcellGrid().get((position + Game.getGridsize())).isMine()) dangerCount++;
                        if(Grid.getcellGrid().get((position - Game.getGridsize() - 1)).isMine()) dangerCount++;
                        if(Grid.getcellGrid().get((position + Game.getGridsize() - 1)).isMine()) dangerCount++;
                        if(Grid.getcellGrid().get((position - 1)).isMine()) dangerCount++;
                    } else {
                        if(Grid.getcellGrid().get((position - Game.getGridsize())).isMine()) dangerCount++;
                        if(Grid.getcellGrid().get((position + Game.getGridsize())).isMine()) dangerCount++;
                        if(Grid.getcellGrid().get((position - Game.getGridsize() - 1)).isMine()) dangerCount++;
                        if(Grid.getcellGrid().get((position + Game.getGridsize() - 1)).isMine()) dangerCount++;
                        if(Grid.getcellGrid().get((position - Game.getGridsize() + 1)).isMine()) dangerCount++;
                        if(Grid.getcellGrid().get((position + Game.getGridsize() + 1)).isMine()) dangerCount++;
                        if(Grid.getcellGrid().get((position - 1)).isMine()) dangerCount++;
                        if(Grid.getcellGrid().get((position + 1)).isMine()) dangerCount++;
                    }
                    cell.setText(String.valueOf(dangerCount));
                } 
                else if(cell.getType() == 1 || cell.getType() == 3){
                    for(int x = 0; x < Grid.getcellGrid().size(); x++) {
                        Grid.getcellGrid().get(x).setEnabled(false);
                        Grid.getcellGrid().get(x).setText("");

                        if(Grid.getcellGrid().get(x).getType() == 1){
                            Grid.getcellGrid().get(x).setText("M");
                        }else if(Grid.getcellGrid().get(x).getType() == 3){
                            Grid.getcellGrid().get(x).setText("S");
                        }
                    }
                    cell.setText(":(");
                    Game.setLose(true);
                    ClockPane.setTime((int)((System.currentTimeMillis() - ClockPane.gettime())/1000));
                    new SaveAttempt();
                }  

                for(int x = 0; x < queue.size(); x++) {
                    if(!queue.get(x).isDiscovered()) {
                        current.add(queue.get(x));
                        queue.get(x).setDiscovered(true);
                    }
                }
                queue.clear();

                while(!current.isEmpty()) {
                    Cell temp = current.get(0);
                    current.remove(0);
                    temp.clickButton();
                }

                for(int x = 0; x < Grid.getcellGrid().size(); x++) {
                    if(Grid.getcellGrid().get(x).isDiscovered()) {
                        discoveredCells++;
                    }
                }

                if(discoveredCells == Grid.getcellGrid().size() - Game.getMinetemp()) {
                    for(int x = 0; x < Grid.getcellGrid().size(); x++) {
                        if(Grid.getcellGrid().get(x).getType() == 1) {
                            Grid.getcellGrid().get(x).setEnabled(false);
                            Grid.getcellGrid().get(x).setText("M");
                        } else if (Grid.getcellGrid().get(x).getType() == 3) {
                            Grid.getcellGrid().get(x).setEnabled(false);
                            Grid.getcellGrid().get(x).setText("S");
                        }else{
                            Grid.getcellGrid().get(x).setEnabled(false);
                            Grid.getcellGrid().get(x).setText(" ");
                        }
                    }
                    Game.setWin(true);
                    ClockPane.setTime((int)((System.currentTimeMillis() - ClockPane.gettime())/1000));
                    new SaveAttempt();
                }
            }  
        }
    }

    public void rightClick(Cell cell){
        if(!Game.getWin() && !Game.getLose()){
            if(!cell.isDiscovered()){
            if(!cell.isFlagged() && Game.getFlaggedcells() < Game.getMinetemp()){
                if(Game.getAttempts() < 4 && cell.getType() == 3){
                    //ανοίγω όλα τα κελιά στην ίδια στήλη και ίδια γραμμή
                    cell.setText("S");
                    cell.setDiscovered(true);
                    cell.setEnabled(false);
                    int temp = Game.getMinetemp(); --temp;
                    Game.setMinetemp(temp);

                    int pos = cell.getPosition(), 
                    position,
                    x_axis = pos % Game.getGridsize(), 
                    y_axis =  (int)(pos / Game.getGridsize()); 

                    for(int row=0; row<Game.getGridsize(); row++){
                        position = y_axis*Game.getGridsize() + row;
                        if(pos != position){
                            Grid.getcellGrid().get(position).setEnabled(false);
                            Grid.getcellGrid().get(position).setDiscovered(true);
                            System.out.println(Grid.getcellGrid().get(position).getType());

                            if(Grid.getcellGrid().get(position).getType() == 1){
                                Grid.getcellGrid().get(position).setText("M");
                                temp = Game.getMinetemp(); --temp;
                                Game.setMinetemp(temp);
                            }else if(Grid.getcellGrid().get(position).getType() == 0){
                                Grid.getcellGrid().get(position).setText("");
                            }else if(Grid.getcellGrid().get(position).getType() == 2){
                                int dangerCount = 0;
                                if(position < Game.getGridsize()) {
                                    if(position % Game.getGridsize() == 0) {
                                        if(Grid.getcellGrid().get(position + Game.getGridsize()).isMine()) dangerCount++;
                                        if(Grid.getcellGrid().get(position + Game.getGridsize() + 1).isMine()) dangerCount++; 
                                        if(Grid.getcellGrid().get(position + 1).isMine()) dangerCount++;
                                    } else if(position % Game.getGridsize() == Game.getGridsize() - 1) {
                                        if(Grid.getcellGrid().get(position + Game.getGridsize()).isMine()) dangerCount++;
                                        if(Grid.getcellGrid().get(position + Game.getGridsize() - 1).isMine()) dangerCount++;
                                        if(Grid.getcellGrid().get(position - 1).isMine()) dangerCount++;
                                    } else {
                                        if(Grid.getcellGrid().get(position + Game.getGridsize()).isMine()) dangerCount++;
                                        if(Grid.getcellGrid().get(position + Game.getGridsize() + 1).isMine()) dangerCount++;
                                        if(Grid.getcellGrid().get(position + Game.getGridsize() - 1).isMine()) dangerCount++;
                                        if(Grid.getcellGrid().get(position + 1).isMine()) dangerCount++;
                                        if(Grid.getcellGrid().get(position - 1).isMine()) dangerCount++;
                                        System.out.println(dangerCount);
                                    }
                                } else if(position >= (Game.getGridsize() * (Game.getGridsize() - 1))) {
                                    if(position % Game.getGridsize() == 0) {
                                        if(Grid.getcellGrid().get(position - Game.getGridsize()).isMine()) dangerCount++;
                                        if(Grid.getcellGrid().get(position - Game.getGridsize() + 1).isMine()) dangerCount++;
                                        if(Grid.getcellGrid().get(position + 1).getType() == 1) dangerCount++;
                                    } else if(position % Game.getGridsize() == Game.getGridsize() - 1) {
                                        if(Grid.getcellGrid().get(position - Game.getGridsize()).isMine()) dangerCount++;
                                        if(Grid.getcellGrid().get(position - Game.getGridsize() - 1).isMine()) dangerCount++;
                                        if(Grid.getcellGrid().get(position - 1).isMine()) dangerCount++;
                                    } else {
                                        if(Grid.getcellGrid().get(position - Game.getGridsize()).isMine()) dangerCount++;
                                        if(Grid.getcellGrid().get(position - Game.getGridsize() + 1).isMine()) dangerCount++;
                                        if(Grid.getcellGrid().get(position - Game.getGridsize() - 1).isMine()) dangerCount++;
                                        if(Grid.getcellGrid().get(position + 1).isMine()) dangerCount++;
                                        if(Grid.getcellGrid().get(position - 1).isMine()) dangerCount++;
                                    }
                                } else if(position % Game.getGridsize() == 0) {
                                    if(Grid.getcellGrid().get(position - Game.getGridsize()).isMine()) dangerCount++;
                                    if(Grid.getcellGrid().get(position + Game.getGridsize()).isMine()) dangerCount++;
                                    if(Grid.getcellGrid().get(position - Game.getGridsize() + 1).isMine()) dangerCount++;
                                    if(Grid.getcellGrid().get(position + Game.getGridsize() + 1).isMine()) dangerCount++;
                                    if(Grid.getcellGrid().get(position + 1).isMine()) dangerCount++;
                                } else if(position % Game.getGridsize() == Game.getGridsize() - 1) {
                                    if(Grid.getcellGrid().get((position - Game.getGridsize())).isMine()) dangerCount++;
                                    if(Grid.getcellGrid().get((position + Game.getGridsize())).isMine()) dangerCount++;
                                    if(Grid.getcellGrid().get((position - Game.getGridsize() - 1)).isMine()) dangerCount++;
                                    if(Grid.getcellGrid().get((position + Game.getGridsize() - 1)).isMine()) dangerCount++;
                                    if(Grid.getcellGrid().get((position - 1)).isMine()) dangerCount++;
                                } else {
                                    if(Grid.getcellGrid().get((position - Game.getGridsize())).isMine()) dangerCount++;
                                    if(Grid.getcellGrid().get((position + Game.getGridsize())).isMine()) dangerCount++;
                                    if(Grid.getcellGrid().get((position - Game.getGridsize() - 1)).isMine()) dangerCount++;
                                    if(Grid.getcellGrid().get((position + Game.getGridsize() - 1)).isMine()) dangerCount++;
                                    if(Grid.getcellGrid().get((position - Game.getGridsize() + 1)).isMine()) dangerCount++;
                                    if(Grid.getcellGrid().get((position + Game.getGridsize() + 1)).isMine()) dangerCount++;
                                    if(Grid.getcellGrid().get((position - 1)).isMine()) dangerCount++;
                                    if(Grid.getcellGrid().get((position + 1)).isMine()) dangerCount++;
                                }
                                Grid.getcellGrid().get(position).setText(String.valueOf(dangerCount));

                            }
                        }    
                    }

                    for(int col = 0; col<Game.getGridsize();col++){
                        position = x_axis + col*Game.getGridsize();
                        if(pos != position){
                            Grid.getcellGrid().get(position).setEnabled(false);
                            Grid.getcellGrid().get(position).setDiscovered(true);

                            if(Grid.getcellGrid().get(position).getType() == 1){
                                Grid.getcellGrid().get(position).setText("M");
                                temp = Game.getMinetemp(); --temp;
                                Game.setMinetemp(temp);
                            }else if(Grid.getcellGrid().get(position).getType() == 0){
                                Grid.getcellGrid().get(position).setText("");
                            }else if(Grid.getcellGrid().get(position).getType() == 2){
                                int dangerCount = 0;
                                if(position < Game.getGridsize()) {
                                    if(position % Game.getGridsize() == 0) {
                                        if(Grid.getcellGrid().get(position + Game.getGridsize()).isMine()) dangerCount++;
                                        if(Grid.getcellGrid().get(position + Game.getGridsize() + 1).isMine()) dangerCount++; 
                                        if(Grid.getcellGrid().get(position + 1).isMine()) dangerCount++;
                                    } else if(position % Game.getGridsize() == Game.getGridsize() - 1) {
                                        if(Grid.getcellGrid().get(position + Game.getGridsize()).isMine()) dangerCount++;
                                        if(Grid.getcellGrid().get(position + Game.getGridsize() - 1).isMine()) dangerCount++;
                                        if(Grid.getcellGrid().get(position - 1).isMine()) dangerCount++;
                                    } else {
                                        if(Grid.getcellGrid().get(position + Game.getGridsize()).isMine()) dangerCount++;
                                        if(Grid.getcellGrid().get(position + Game.getGridsize() + 1).isMine()) dangerCount++;
                                        if(Grid.getcellGrid().get(position + Game.getGridsize() - 1).isMine()) dangerCount++;
                                        if(Grid.getcellGrid().get(position + 1).isMine()) dangerCount++;
                                        if(Grid.getcellGrid().get(position - 1).isMine()) dangerCount++;
                                        System.out.println(dangerCount);
                                    }
                                } else if(position >= (Game.getGridsize() * (Game.getGridsize() - 1))) {
                                    if(position % Game.getGridsize() == 0) {
                                        if(Grid.getcellGrid().get(position - Game.getGridsize()).isMine()) dangerCount++;
                                        if(Grid.getcellGrid().get(position - Game.getGridsize() + 1).isMine()) dangerCount++;
                                        if(Grid.getcellGrid().get(position + 1).getType() == 1) dangerCount++;
                                    } else if(position % Game.getGridsize() == Game.getGridsize() - 1) {
                                        if(Grid.getcellGrid().get(position - Game.getGridsize()).isMine()) dangerCount++;
                                        if(Grid.getcellGrid().get(position - Game.getGridsize() - 1).isMine()) dangerCount++;
                                        if(Grid.getcellGrid().get(position - 1).isMine()) dangerCount++;
                                    } else {
                                        if(Grid.getcellGrid().get(position - Game.getGridsize()).isMine()) dangerCount++;
                                        if(Grid.getcellGrid().get(position - Game.getGridsize() + 1).isMine()) dangerCount++;
                                        if(Grid.getcellGrid().get(position - Game.getGridsize() - 1).isMine()) dangerCount++;
                                        if(Grid.getcellGrid().get(position + 1).isMine()) dangerCount++;
                                        if(Grid.getcellGrid().get(position - 1).isMine()) dangerCount++;
                                    }
                                } else if(position % Game.getGridsize() == 0) {
                                    if(Grid.getcellGrid().get(position - Game.getGridsize()).isMine()) dangerCount++;
                                    if(Grid.getcellGrid().get(position + Game.getGridsize()).isMine()) dangerCount++;
                                    if(Grid.getcellGrid().get(position - Game.getGridsize() + 1).isMine()) dangerCount++;
                                    if(Grid.getcellGrid().get(position + Game.getGridsize() + 1).isMine()) dangerCount++;
                                    if(Grid.getcellGrid().get(position + 1).isMine()) dangerCount++;
                                } else if(position % Game.getGridsize() == Game.getGridsize() - 1) {
                                    if(Grid.getcellGrid().get((position - Game.getGridsize())).isMine()) dangerCount++;
                                    if(Grid.getcellGrid().get((position + Game.getGridsize())).isMine()) dangerCount++;
                                    if(Grid.getcellGrid().get((position - Game.getGridsize() - 1)).isMine()) dangerCount++;
                                    if(Grid.getcellGrid().get((position + Game.getGridsize() - 1)).isMine()) dangerCount++;
                                    if(Grid.getcellGrid().get((position - 1)).isMine()) dangerCount++;
                                } else {
                                    if(Grid.getcellGrid().get((position - Game.getGridsize())).isMine()) dangerCount++;
                                    if(Grid.getcellGrid().get((position + Game.getGridsize())).isMine()) dangerCount++;
                                    if(Grid.getcellGrid().get((position - Game.getGridsize() - 1)).isMine()) dangerCount++;
                                    if(Grid.getcellGrid().get((position + Game.getGridsize() - 1)).isMine()) dangerCount++;
                                    if(Grid.getcellGrid().get((position - Game.getGridsize() + 1)).isMine()) dangerCount++;
                                    if(Grid.getcellGrid().get((position + Game.getGridsize() + 1)).isMine()) dangerCount++;
                                    if(Grid.getcellGrid().get((position - 1)).isMine()) dangerCount++;
                                    if(Grid.getcellGrid().get((position + 1)).isMine()) dangerCount++;
                                }
                                Grid.getcellGrid().get(position).setText(String.valueOf(dangerCount));
                            }
                        }
                    }

                }
                else if(cell.getType() != 3 || Game.getAttempts() >= 4){
                    cell.setFlagged(true);
                    cell.setText("F");
                    int temp = Game.getFlaggedcells(); temp++;
                    Game.setFlaggedcells(temp);
                }

            }
            else if(cell.isFlagged()){
                cell.setFlagged(false);
                cell.setText("");
                int temp = Game.getFlaggedcells(); --temp;
                Game.setFlaggedcells(temp);
            }
        }
            ClockPane.tickTock();
        }
    }

}
