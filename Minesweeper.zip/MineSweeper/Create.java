import java.io.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

/**
 * <h1>Creation of a new Scenario</h1>
 * Create class saves a new scenario of a game with the user choose the characteristics
 * For creation a popUp Window opens
 * @param frame JFrame of the popUp Window
 * @param l_title the title of the Scenario - JLabel comments for appropriate save  
 * @param f_title JTextField that represents the f_title_value, the appropriate number
 * @param l_level the level of the Scenario - same-
 * @param f_level -same- f_level_value - 
 * @param l_mines the number of mines - same -
 * @param f_mines - same - f_mines_value 
 * @param l_supermine if we have supermine or not - same - 
 * @param f_supermine - same - f_supermine_value - same - 
 * @param l_time timelimit -same-
 * @param f_time -same- f_time_value -same-
 * <p>
 * @param button Jbutton "Submit" that submits the new Scenario and saves it 
 * in a input text file with appropriate name
 * @exception IOException
 * */

public class Create implements ActionListener{

	private static JFrame frame;
	private static String title = "Create New Game";
    private JLabel l_title, l_level, l_mines, l_supermine, l_time;
    private JTextField f_title, f_level, f_mines, f_supermine, f_time;
    private int f_title_value, f_level_value, f_mines_value, f_supermine_value, f_time_value;
    private JButton button;
    private BufferedWriter writer;
	
	public Create() {
		frame = new JFrame(title);
		frame.setPreferredSize(new Dimension((int)(Game.getWidth()/2),(int)(Game.getHeight()/2)));
        frame.setMinimumSize(new Dimension((int)(Game.getWidth()/2),(int)(Game.getHeight()/2)));
        frame.setMaximumSize(new Dimension((int)(Game.getWidth()/2),(int)(Game.getHeight()/2)));
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setTitle(title);
        frame.setFont(new Font("Courier", Font.BOLD,100));
        frame.setFont(frame.getFont().deriveFont(10f)); 

        l_title = new JLabel("Title: [10-50]");
        f_title = new JTextField(20);

        l_level = new JLabel("Level: [1-2]");
        f_level = new JTextField(20);

        l_mines = new JLabel("No_Mines: Level_1->[9-11] || Level_2->[35-45]");
        f_mines = new JTextField(20);

        l_supermine = new JLabel("SuperMine: Level_1->0 || Level_2->1");
        f_supermine = new JTextField(20);
 		
 		l_time = new JLabel("Time_limit: Level_1->[120-180] || Level_2->[240-360]");
        f_time = new JTextField(20);

        button = new JButton("Submit");
        button.addActionListener(this);

        JPanel pane = new JPanel();
        pane.setLayout(new BoxLayout(pane, BoxLayout.Y_AXIS));

        pane.add(l_title); pane.add(f_title); 
        pane.add(l_level); pane.add(f_level);
        pane.add(l_mines); pane.add(f_mines);
        pane.add(l_supermine); pane.add(f_supermine);
        pane.add(l_time); pane.add(f_time);
        pane.add(button);

        frame.add(pane);
        frame.setContentPane(pane);
        frame.pack();
        frame.setVisible(true);

        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                        // Ask for confirmation before terminating the program.
                int option = JOptionPane.showConfirmDialog(
                    frame, 
                    "Are you sure you want to close the window?",
                    "Close Confirmation", 
                    JOptionPane.YES_NO_OPTION, 
                    JOptionPane.QUESTION_MESSAGE);
                if (option == JOptionPane.YES_OPTION) {
                    frame.dispose();
                }
            }
        });


	}


	public void actionPerformed(ActionEvent ae){
    	f_title_value = Integer.valueOf(f_title.getText());
    	f_level_value = Integer.valueOf(f_level.getText()); 
    	f_mines_value = Integer.valueOf(f_mines.getText());
    	f_supermine_value = Integer.valueOf(f_supermine.getText());
    	f_time_value = Integer.valueOf(f_time.getText());
        if(ae.getSource() == button){
            if(
                !(f_title_value < 10 || f_title_value > 50) &&
                !(f_level_value > 2 || f_level_value < 1) && 
                !(f_level_value == 1 && (f_mines_value < 9 || f_mines_value > 11)) && 
                !(f_level_value == 2 && (f_mines_value < 35 || f_mines_value > 45)) &&
                !(f_level_value == 1 && (f_time_value < 120 || f_time_value > 180)) &&
                !(f_level_value == 2 && (f_time_value < 240 || f_time_value > 360)) &&
                !(f_level_value == 1 && f_supermine_value != 0) &&
                !(f_level_value == 2 && f_supermine_value != 1)
            ){
                frame.dispose();
                try{
                    writer = new BufferedWriter(new FileWriter("C:/Users/John/Desktop/MineSweeper/input/SCENARIO-ID[" + f_title_value + "].txt"));
                    writer.write(String.valueOf(f_level_value));
                    writer.newLine();
                    writer.write(String.valueOf(f_mines_value));
                    writer.newLine();
                    writer.write(String.valueOf(f_time_value));
                    writer.newLine();
                    writer.write(String.valueOf(f_supermine_value));
                   

                    writer.flush();
                    writer.close();
                }catch(IOException e){e.getMessage();}
            }
        }
      
   }
	
	public static void main(String... args) {
        new Create();
    }

}

