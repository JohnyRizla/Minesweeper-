import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.awt.event.*;
public class StartGame{
	
	/**
	 * <h1> Start the Game! </h1>
	 * The constructor is called with:
	 * @param s String s, for scenario input: SCENARIO-ID[s].txt. 
	 * The StartGame calls the Game constructor
	 * 
	 * @author Ioannis Rizas
	 * @since 2023-01-08
	 */

	public StartGame(String s){
		new Game(s);
	}

	public static void main(String... args){
		new StartGame(args[0]);
	}
}