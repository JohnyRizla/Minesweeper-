import java.io.*;

/**
 * <h1>Save attempts</h1>
 * SaveAttempt constructor is called when we want to store the results of the current Game in the "latest_attempts.txt" file
 * @param savings the info that we want to store in the text file
 * @param lines the info that we have read from the text file with the method "getAttempts()"
 * @param cnt how many lines the text file has
 * @exception IOException
 * */

public class SaveAttempt{

	private int[][] savings;  
	private static BufferedReader reader;
	private BufferedWriter writer;
	
	private static int[][] lines;
	private static int cnt;

	public SaveAttempt() {
		this.savings = new int[5][4]; //0: Mines , 1: Attempts , 2: Time , 3: Win
		this.lines = new int[6][4];
		this.cnt = 0;
		try {
			getAttempts(); //δίνεται το lines και το cnt
			if(cnt == 6){--cnt;}
			// 1->5 := recent->old
			this.savings[0][0] = Grid.getmines().size();
			this.savings[0][1] = Game.getAttempts();
			this.savings[0][2] = ClockPane.getTime();
			this.savings[0][3] = ((Game.getWin()) ? 1 : 0);

			for(int i = 1; i < cnt; i++){
				for(int k = 0; k < 4; k++){
					this.savings[i][k] = lines[i][k];
				}
			}
			this.writer = new BufferedWriter(new FileWriter("C:/Users/John/Desktop/MineSweeper/latest_attempts.txt"));
			this.writer.write("M A T W");
			this.writer.newLine();
			for(int i = 0; i < cnt; i++){
				this.writer.write(
					String.valueOf(this.savings[i][0]) + " " + 
					String.valueOf(this.savings[i][1]) + " " +
					String.valueOf(this.savings[i][2]) + " " +
					String.valueOf(this.savings[i][3])
				);
				this.writer.newLine();
			}
			this.writer.flush();
			this.writer.close();

		}catch(IOException e){System.out.println(e.getMessage());}

	}

	/**
	 * We use it and outside of the constructor in Rounds class to print the file
	 * @exception IOException
	 * @param s Temporary Array of Strings for reading properly the text file 
	 * */

	public static void getAttempts(){
		try{
			String[] s = new String[4];
			String temp;
			reader = new BufferedReader(new FileReader("C:/Users/John/Desktop/MineSweeper/latest_attempts.txt"));
			temp = reader.readLine();
			
			do {
				++cnt;
				temp = reader.readLine();
				if(temp == null){break;}

				s = temp.split(" ");
				for(int i = 0; i < 4; i++){
					lines[cnt][i] = Integer.valueOf(s[i]);
				}
			} while(true);
			
			reader.close();
		}catch(IOException e){System.out.println(e.getMessage());}
	}
}