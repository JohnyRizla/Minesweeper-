import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.EmptyBorder;
import java.io.*;

/**
 * <h1>Rounds</h1>
 * Rounds class open an a text file with the name "latest_attempts" 
 * that have the 5 most recent attempts of the player
 * @param path the path of the text file
 * @param frame the frame of the popUp Window
 * @exception FileNotFOundException
 * @exception IOException
 * */

public class Rounds{
	private JFrame frame;
	private String title;
	private FileReader reader;
	private static String path = "C:/Users/John/Desktop/MineSweeper/latest_attempts.txt";
	private String[] s;

	public Rounds(){
        title = "Latest_Attempts";
		frame = new JFrame(title);
		frame.setPreferredSize(new Dimension((int)(Game.getWidth()/2),(int)(Game.getHeight()/2)));
        frame.setMinimumSize(new Dimension((int)(Game.getWidth()/2),(int)(Game.getHeight()/2)));
        frame.setMaximumSize(new Dimension((int)(Game.getWidth()/2),(int)(Game.getHeight()/2)));
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setTitle(title);
        frame.setFont(new Font("Courier", Font.BOLD,200));

        JTextArea area = new JTextArea(20, 20);
        try{
        	reader = new FileReader(path);
        	
        }catch(FileNotFoundException e){e.getMessage();}
        try{
        	area.read(reader, path);
        }catch(IOException e){e.getMessage();}

        area.setFont(area.getFont().deriveFont(35f)); 

        frame.add(area, null);
        frame.setContentPane(area);
        frame.pack();
        frame.setVisible(true);
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                        // Ask for confirmation before terminating the program.
                int option = JOptionPane.showConfirmDialog(
                    frame, 
                    "Are you sure you want to close the window?",
                    "Close Confirmation", 
                    JOptionPane.YES_NO_OPTION, 
                    JOptionPane.QUESTION_MESSAGE);
                if (option == JOptionPane.YES_OPTION) {
                    frame.dispose();
                }
            }
        });

	}
    /**
     * The main method doesn't do anything. Its only ther for the testing
     * */

    public static void main(String... args) {
        new Rounds();
    }

}