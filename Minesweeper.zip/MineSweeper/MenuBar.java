import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

/**
 * <h1>MenuBar!</h1>
 * The MenuBar class creates a menubar inside the frame of the Window class 
 * that adds some functionalities:
 * @param i7 Restart button
 * <p>
 * For Application Menu:
 * @param i1 "Create new Game" button, calling the Create constructor: 			
 *	We give variables:
 *		1)give number x of the text file SCENARIO-ID[x].txt 
 *		2)level
 *		3)#mines
 *		4)SuperMine or not
 *		5)TimeLimit
 *	We check if:
 *		(a)the info is valid for save and if it's not the user have to retry for new creation
 *		(b)number must been between 10-50. 10 first numbers are for the testing of the system
 *	If they are all ready, we create a new input text file			
 * @param i2 "Load a game" button, calling the Load constructor
 * @param i3 "Start a load Game" button that starts a game if and only if the game is loaded, 
 * calls the StartGame constructor 
 * @param i4 "Exit game" that closes the Application
 * <p>
 * For "Details" Menu:
 * @param i5 "Rounds" that create a popUp Window that shows the 5 last attempts for playing, 
 * calling the Rounds constructor 
 * @param i6 "Solution" that Save the game as an attempt calling the SaveAttempt constructor 
 * and shows the mines in the Grid and stops the time
 * <p>
 * @param appmenu JMenu that contains create, load, start and exit buttons
 * @param detmenu JMenu that contains rounds and solution buttons
 * @param menu JMenu contains the appmenu, detmenu and i7 (restart button) 
 * @param mb JMenuBar contains the JMenu menu
 * 
 * */

public class MenuBar implements ActionListener {
	//private JFrame f;
	//private JPanel p;

	private JMenuBar mb;
	private JMenu menu, appmenu, detmenu;
	private JButton i1, i2, i3, i4, i5, i6, i7;
	private static boolean SOL;

	public MenuBar(){
		//f = new JFrame();
		//p = new JPanel(new BorderLayout());
		SOL = false;
		mb = new JMenuBar();
		mb.add(Box.createHorizontalGlue());
		//mb.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);

		menu = new JMenu("Menu");
		menu.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
		menu.setHorizontalAlignment(SwingConstants.LEFT);
		
		appmenu = new JMenu("Application");
		i1 = new JButton("Create");
		i2 = new JButton("Load");
		i3 = new JButton("Start");
		i4 = new JButton("Exit");
		appmenu.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
		appmenu.setHorizontalAlignment(SwingConstants.LEFT);

		detmenu = new JMenu("Details");
		i5 = new JButton("Rounds");
		i6 = new JButton("Solution");
		detmenu.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
		detmenu.setHorizontalAlignment(SwingConstants.LEFT);

		i7 = new JButton("Restart");
		
		appmenu.add(i1);
		appmenu.add(i2);
		appmenu.add(i3);
		appmenu.add(i4);
		
		detmenu.add(i5);
		detmenu.add(i6);

		menu.add(i7);
		menu.add(appmenu);
		menu.add(detmenu);

		menu.setMnemonic(KeyEvent.VK_A);
		mb.add(menu);
		mb.revalidate();
		
		i1.addActionListener(this);
		i2.addActionListener(this);
		i3.addActionListener(this);
		i4.addActionListener(this);
		i5.addActionListener(this);
		i6.addActionListener(this);
		i7.addActionListener(this);

	}

	public static boolean getSol(){
		return SOL;
	}

	public JMenuBar getMenuBar(){
		return mb;
	}

	public void actionPerformed(ActionEvent e){
		if(e.getSource() == i1){	//Create
			new Create();
		}
			
		if(e.getSource() == i2){	//Load
			new Load();
		}
			
		if(e.getSource() == i3){	//Start
			if(Load.getLoaded()){
				int option = JOptionPane.showConfirmDialog(
	                mb, 
	                "Are you sure you want to start a new game?",
	                "Close Confirmation", 
	                JOptionPane.YES_NO_OPTION, 
	                JOptionPane.QUESTION_MESSAGE);
	            if (option == JOptionPane.YES_OPTION) {
	            	Window.frame_dispose();
					new StartGame(Load.getScenarioID());
	            }
			}
			
		}
			
		if(e.getSource() == i4){
            int option = JOptionPane.showConfirmDialog(
                mb, 
                "Are you sure you want to exit?",
                "Close Confirmation", 
                JOptionPane.YES_NO_OPTION, 
                JOptionPane.QUESTION_MESSAGE);
            if (option == JOptionPane.YES_OPTION) {
                System.exit(0);
            }

		}

		if(e.getSource() == i5){	//Rounds
			new Rounds();
		}
			
		if(e.getSource() == i6){	//Solution
			SOL = true;
			for(int x = 0; x < Grid.getcellGrid().size(); x++) {
                if(Grid.getcellGrid().get(x).getType() == 1) {
                    Grid.getcellGrid().get(x).setEnabled(false);
                    Grid.getcellGrid().get(x).setText("M");
                } else if (Grid.getcellGrid().get(x).getType() == 3) {
                    Grid.getcellGrid().get(x).setEnabled(false);
                    Grid.getcellGrid().get(x).setText("S");
                }else{
                    Grid.getcellGrid().get(x).setEnabled(false);
                    Grid.getcellGrid().get(x).setText(" ");
                }
            }
			Game.setLose(true);
			ClockPane.setTime((int)((System.currentTimeMillis() - ClockPane.gettime())/1000));
			new SaveAttempt();
		}
		if(e.getSource() == i7){ //Restart
			int option = JOptionPane.showConfirmDialog(
                mb, 
                "Are you sure you want to restart the game?",
                "Close Confirmation", 
                JOptionPane.YES_NO_OPTION, 
                JOptionPane.QUESTION_MESSAGE);
            if (option == JOptionPane.YES_OPTION) {
            	String s = Game.getIn();
            	Window.frame_dispose();
				new StartGame(s);
            }
		}
			
	}

	public static void main(String args[]){
		new MenuBar();
	}

}