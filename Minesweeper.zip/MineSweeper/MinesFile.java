import java.io.*;

/**
 * <h1>Mines saved in mines file </h1>
 * The MinesFIle class saves in:
 * @param path the path of the appropriate txt file
 * 1)The cordinates (x, y) of its mine
 * 2)If a mine is supermine or not  
 * @param writer BufferedWriter for saving the info
 * @exception IOException
 * */

public class MinesFile{

	private BufferedWriter writer;
	private int x_axis;
	private int y_axis;
	private String path;

	public MinesFile() {
		try{
			path = "C:/Users/John/Desktop/MineSweeper/mines/mines[" + Game.getIn() + "].txt";
			this.writer = new BufferedWriter(new FileWriter(path));
			for(int i=0; i<Grid.getmines().size();i++){
				this.x_axis = Grid.getmines().get(i) % Game.getGridsize();
				this.y_axis = (int) (Grid.getmines().get(i)/Game.getGridsize());
				if(Grid.getSupermineposition() != Grid.getmines().get(i)){
					this.writer.write(String.valueOf(this.x_axis) + " " + String.valueOf(this.y_axis) + " 0");
				}else{
					this.writer.write(String.valueOf(this.x_axis) + " " + String.valueOf(this.y_axis) + " 1");
				}
				this.writer.newLine();
			}
			this.writer.flush();
			this.writer.close();
		}catch(IOException e){e.getStackTrace();}
	}

}