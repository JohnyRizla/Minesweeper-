import java.io.*;

/** 
 * The InputFile class initializes all the crucial parameters 
 * of the Game class opening the Game input that exists in a file
 * @param path is the path for the input 
 * @param reader BufferedReader that reads the text input file in a specific path 
 * @param arr Array of 4 cells that represents : 0: Level , 1: Mines , 2: MaxTime , 3: SuperMine
 * <p>
 * @exception IOException("InvalidDescriptionException") checks if the text file has more or less lines than 4
 * @exception IOException("InvalidValueException") checks if value of the text file's parameters are in a specific range
 * @see https://docs.oracle.com/javase/7/docs/api/java/io/IOException.html
 * 
 * */

public class InputFile{

	private BufferedReader reader;
	private String path;
	private static int[] arr = new int[4]; 

	public InputFile(String s) {
		try {
			path = "C:/Users/John/Desktop/MineSweeper/input/SCENARIO-ID[" + s + "].txt";
			reader = new BufferedReader(new FileReader(path));
			String line = reader.readLine();
			int cnt= 0;
			while (line != null) {
				line = reader.readLine();
				cnt++; 
			}
			if(cnt != 4){throw new IOException("InvalidDescriptionException");}
			reader.close();

			reader = new BufferedReader(new FileReader(path));
			for(int i=0; i<4; i++){
				 arr[i] = Integer.valueOf(reader.readLine());
			}
			reader.close();

			if(
				(arr[0]>2 || arr[0] <1) || 
				(arr[0] == 1 && (arr[1] < 9 || arr[1] > 11)) || 
				(arr[0] == 2 && (arr[1] < 35 || arr[1] > 45)) ||
				(arr[0] == 1 && (arr[2] < 120 || arr[2] >180)) ||
				(arr[0] == 2 && (arr[2] <240 || arr[2]>360)) ||
				(arr[0] == 1 && arr[3] != 0) ||
				(arr[0] == 2 && arr[3] != 1)
			){throw new IOException("InvalidValueException");}
			else{
				Game.setMinecount(arr[1]);
				Game.setTimelimit(arr[2]);
				Game.setSupermine((arr[3] == 0) ? false : true);
				if(arr[0] == 1)Game.setGridsize(9);
				else Game.setGridsize(16);

				System.out.println(arr[0]+ " " + ((arr[0] ==1) ? 9 : 16) + " " + arr[1] + " " + arr[2] + " " + arr[3]);
			}

		}catch(IOException e){System.out.println(e.getMessage());}

	}
}