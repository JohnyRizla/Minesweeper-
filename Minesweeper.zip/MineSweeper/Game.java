public class Game {

    private static int WIDTH, HEIGHT, GRIDSIZE, MINECOUNT, TIMELIMIT, FLAGGEDCELLS, ATTEMPTS, MINETEMP;
    private static boolean SUPERMINE, WIN, LOSE;
    private static String IN;

    private Handler handler = new Handler();

    /**
     * <h1> Game parameters were initialized </h1>
     * Game constructor initialize all the significant parameters 
     * for the game through the InputFile constructor with paramemeter
     * @param in String for the SCENARIO_ID[in].txt
     * and then calls the Window constructor to create the frame of the game 
     */

    public Game(String in) {
        this.SUPERMINE = false;
        new InputFile(in);
        this. MINETEMP = this.MINECOUNT;
        this.WIDTH = 800;
        this.HEIGHT = 800;
        this.FLAGGEDCELLS = 0;
        this.ATTEMPTS = 0;
        this.WIN = false;
        this.LOSE = false;
        this.IN = in;
        new Window(this.WIDTH, this.HEIGHT, this.GRIDSIZE, String.format("%100s Minesweeper", " "), this, this.handler);
    }
    /**
     * Main method
     * @param args
     * It doesn't do anything. Its only for testing
     * 
     */

    public static void main(String[] args) {
        new Game(args[0]);
    }

    /**
     * 
     */

    public static void setWidth(int w){
        WIDTH = w;
    }

    public static int getWidth(){
        return WIDTH;
    }

    public static void setHeight(int h){
        HEIGHT = h;
    }

    public static int getHeight(){
        return HEIGHT;
    }

    public static void setGridsize(int g){
        GRIDSIZE = g;
    }

    public static int getGridsize(){
        return GRIDSIZE;
    }

    public static void setMinecount(int mc){
        MINECOUNT = mc;
    }

    public static int getMinecount(){
        return MINECOUNT;
    }

    public static void setMinetemp(int mt){
        MINETEMP = mt;
    }

    public static int getMinetemp(){
        return MINETEMP;
    }

    public static void setTimelimit(int t){
        TIMELIMIT = t;
    }

    public static int getTimelimit(){
        return TIMELIMIT;
    }

    public static void setFlaggedcells(int f){
        FLAGGEDCELLS = f;
    }

    public static int getFlaggedcells(){
        return FLAGGEDCELLS;
    }

    public static void setAttempts(int at){
        ATTEMPTS = at;
    }

    public static int getAttempts(){
        return ATTEMPTS;
    }

    public static void setSupermine(boolean sm){
        SUPERMINE = sm;
    }

    public static boolean getSupermine(){
        return SUPERMINE;
    }

    public static void setWin(boolean w){
        WIN = w;
    }

    public static boolean getWin(){
        return WIN;
    }

    public static void setLose(boolean l){
        LOSE = l;
    }

    public static boolean getLose(){
        return LOSE;
    }

    public static void setIn(String in){
        IN = in;
    }

    public static String getIn(){
        return IN;
    }
}
