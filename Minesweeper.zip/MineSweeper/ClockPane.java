import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * <h1>TickTock!</h1>
 * ClockPane class implements a live clock and prints in the main frame in Window class 
 * the live parameters of the Game that a player wants to know about:
 * 1)#Mines
 * 2)#Flags
 * ( 3)SuperMinePosition , we add it for testing the program more easily. In the client we delete it)
 * 4)Time in seconds available before the Game ends 
 * <p>
 * For the timer:
 * @see http://www.java2s.com/Tutorials/Java/Data_Type_How_to/Legacy_Date_Time/Add_real_time_date_and_time_into_a_JFrame_component.html
 * */
class ClockPane extends JPanel {

	private static int TIME; 
	private static long time;  
	private static JLabel clock;
	private static String pad = String.format("%5s", " ");

	public ClockPane() {
		TIME = -1; //it hasn't finished yet
		time = System.currentTimeMillis();
		clock = new JLabel("Time");
		setLayout(new BorderLayout());
		tickTock();
		add(clock);
		Timer timer = new Timer(1000, new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				tickTock();
			}
		});
		timer.setRepeats(true);
		timer.setCoalesce(true);
		timer.setInitialDelay(0);
		timer.start();
	}

	public static void tickTock() {
		if(!Game.getWin() && (int)((System.currentTimeMillis() - time)/1000) == Game.getTimelimit()){
			Game.setLose(true);
			TIME =  Game.getTimelimit();
			new SaveAttempt();
		}

		if(Game.getLose()){
			if(MenuBar.getSol()){
				clock.setText("Here is the solution");
			}else{
				clock.setText("You exceeded the time. Try again!");
			}
		}else if(!Game.getLose() && !Game.getWin()){
			clock.setText(
				"Mines: " + Game.getMinecount() + 
				pad + "Flags: " + Game.getFlaggedcells() + 
				pad + "Attempts: " + Game.getAttempts() + 
	            pad + "(SuperMine: " + Grid.getSupermineposition() + ")" + 
	            pad + "Time: " + String.valueOf(Game.getTimelimit() - (int)((System.currentTimeMillis() - time)/1000))
        	);
		}else{
			clock.setText("You won in " + String.valueOf(TIME) +" seconds!");
		}
	}

	/**
	 * Some <b>setes</b> and <b>getes</b> for the Handler
	 * */
	
	public static void setTime(int t){
		TIME = t;
	}

	public static int getTime(){
		return TIME;
	}


	public static void settime(long t){
		time = t;
	}

	public static long gettime(){
		return time;
	}
}