import javax.swing.*;
import java.awt.event.*;

/**
 * <h1>Cell creation</h1>
 * The Cell class creates a Cell with a specific characteristics
 * The Grid methods calls multiple times the Cell constructor to create all the Cells in the Grid
 * @param type -- 0: Empty, 1: Mine, 2: Number, 3: SuperMine
 * @param position where in the Grid it is
 * @param discovered if the user has opened it
 * @param flagged if it has tagged with some flag 
 * Flags represents a sign that a cell contains a mine and we should avoid open it. 
 * So in Handler we say that if it is not discovered and not flagged, only then we can investigate some Cells's info
 * @param mine if a Cell is a mine or not
 * @param handler same as Game parameter 
 * 
 * */

public class Cell extends JButton {

    private int type;
    private int position;
    private boolean discovered;
    private boolean flagged;
    private boolean mine;

    private Handler handler;

    public Cell(int type, int position, boolean discovered, boolean flagged, boolean mine, Handler handler) {
        this.type = type;
        this.position = position;
        this.discovered = discovered;
        this.flagged = flagged;
        this.handler = handler;
        this.mine = mine;

        /**We have some Mouse Listeners for the interaction with the cells by clicking
         * For MouseListener:
         * @see https://docs.oracle.com/javase/7/docs/api/java/awt/event/MouseListener.html
         * */

        addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if(SwingUtilities.isRightMouseButton(e)) {
                    rightClickButton();
                } else {
                    if(!isDiscovered()){
                        int temp = Game.getAttempts(); temp++;
                        Game.setAttempts(temp);
                        if(Game.getAttempts() == 4) Game.setSupermine(false);
                        clickButton();
                    }
                }
                ClockPane.tickTock();
            }

            public void mouseEntered(MouseEvent e) {}            
            public void mouseExited(MouseEvent e) {}
            public void mousePressed(MouseEvent e) {}
            public void mouseReleased(MouseEvent e) {}
        });
    }

    /**
     * There are various <b>setes()</b> and <b>getes()</b>
     * for all the Cell characteristics that are usefull in the Handler methods
     * */
    public boolean isMine(){
        return mine;
    }

    public int getType() {
        return type;
    }

    public int getPosition() {
        return position;
    }

    public boolean isDiscovered() {
        return discovered;
    }

    public void setDiscovered(boolean d) {
        this.discovered = d;
    }

    public boolean isFlagged() {
        return flagged;
    }

    public void setFlagged(boolean f) {
        this.flagged = f;
    }

    /** We can leftclick to open a cell or rightclick to flag or unflag the cell*/

    public void clickButton() {
        handler.click(this);
    }

    public void rightClickButton() {
        handler.rightClick(this);
    }

}
