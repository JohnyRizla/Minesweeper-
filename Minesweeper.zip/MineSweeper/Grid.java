import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

/**
 * <h1> Grid creation </h1>
 * Grid class creates the known Grid Panel for the MineSweeper Game
 * First it creates the cells with specific characteristics : initialize the Cells
 * Second it adds the cells in two significant ArrayLists:
 * @param cellGrid an ArrayList that has all the cells of the Grid 
 * @param mines an ArrayList that contains all the mine positions of the Grid
 * <p>
 * @param SuperMinePosition an extra parameter that has the Super mine position:  
 * if it doesn't exists, its -1, else its a positive integer 
 *   
 * */

public class Grid extends JPanel {

    private int bound;
    private boolean picked;
    private static ArrayList<Integer> mines;
    private static ArrayList<Cell> cellGrid;
    private static int SuperMinePosition;

    public Grid(GridLayout g, Handler h) {
        super(g);
        this.bound = Game.getGridsize() * Game.getGridsize();
        this.picked = false;
        this.mines = new ArrayList<Integer>();
        this.cellGrid = new ArrayList<Cell>();
        this.SuperMinePosition = -1;
        createCells(h);
        addCells();
    }

    public void createCells(Handler h) {
        for(int i = 1; i <= Game.getMinecount(); i++) {
            while(!this.picked) {
                int minePosition = (int) (Math.random() * this.bound);
                if (!mines.contains(minePosition)) {
                    mines.add(minePosition);
                    this.picked = true;
                }
            }
            this.picked = false;
        }
        if(Game.getSupermine()){
            SuperMinePosition = mines.get((int)(Math.random() * mines.size()));
        }

        new MinesFile();
        
        for(int i = 0; i < bound; i++) {
            if(mines.contains(i) && SuperMinePosition != i){ 
                cellGrid.add(new Cell(1, i, false, false, true, h));
            }else if(mines.contains(i) && SuperMinePosition == i){
                cellGrid.add(new Cell(3, i, false, false, true, h));
            }else if(i % Game.getGridsize() == 0){
                if(mines.contains(i - Game.getGridsize()) ||
                        mines.contains(i - Game.getGridsize() + 1) ||
                        mines.contains(i + 1) ||
                        mines.contains(i + Game.getGridsize()) ||
                        mines.contains(i + Game.getGridsize() + 1)) {
                    cellGrid.add(new Cell(2, i, false, false, false, h));
                } else {
                    cellGrid.add(new Cell(0, i, false, false, false, h));
                }
            } else if(i % Game.getGridsize() == Game.getGridsize() - 1){
                if(mines.contains(i - Game.getGridsize() - 1) ||
                        mines.contains(i - Game.getGridsize()) ||
                        mines.contains(i - 1) ||
                        mines.contains(i + Game.getGridsize() - 1) ||
                        mines.contains(i + Game.getGridsize())) {
                    cellGrid.add(new Cell(2, i, false, false,false, h));
                } else {
                    cellGrid.add(new Cell(0, i, false, false, false, h));
                }
            }else {
                if(mines.contains(i - Game.getGridsize() - 1) ||
                        mines.contains(i - Game.getGridsize()) ||
                        mines.contains(i - Game.getGridsize() + 1) ||
                        mines.contains(i - 1) ||
                        mines.contains(i + 1) ||
                        mines.contains(i + Game.getGridsize() - 1) ||
                        mines.contains(i + Game.getGridsize()) ||
                        mines.contains(i + Game.getGridsize() + 1)) {
                    cellGrid.add(new Cell(2, i, false, false, false, h));
                } else {
                    cellGrid.add(new Cell(0, i, false, false, false, h));
                }
            }
        }
    }

    private void addCells() {
        for(int i = 0; i < cellGrid.size(); i++) {
            add(cellGrid.get(i));
        }
    }

    /**
     * There is also some <b>getes()</b> and <b>setes()</b> 
     * for the mines and cellGrid that is used in Handler class for the changes of the Cells info
     * 
     * */

    public static ArrayList<Integer> getmines(){
        return mines;
    }

    public static ArrayList<Cell> getcellGrid(){
        return cellGrid;
    }

    public static void setSupermineposition(int smp){
        SuperMinePosition = smp;
    }

    public static int getSupermineposition(){
        return SuperMinePosition;
    }

}
