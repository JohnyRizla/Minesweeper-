import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.awt.event.*;

/**
 * <h1>Window creation!</h1>
 * Window class implements the basic Frame the the user interacts with the Game
 * and they play it
 * @param frame JFrame that reprenets the Basic Frame of the Game
 * @param title the title of the frame
 * @param b a JButton for the Restart the Game: play the Game with the same input again, we implement this for better interaction
 * <p> 
 * The Window class implements a Frame with four things:
 * 1)title
 * 2)MenuBar that exists on the top right of the Window
 * 3)Some live stats from the Game as "Mines" "Attempts" and "Time"
 * 4)the Grid of the known MineSweeper Game
 *
 * */

public class Window {

    private static JFrame frame;
    private static String title;
    private static JButton b;

    public Window(int width, int height, int gridSize, String title, Game game, Handler handler) {
        Window.title = title;
        frame = new JFrame(title);
        frame.setPreferredSize(new Dimension(width, height));
        frame.setMinimumSize(new Dimension(width, height));
        frame.setMaximumSize(new Dimension(width, height));
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setTitle(title);
        frame.setFont(new Font("Courier", Font.BOLD,75));

        /**
         * @param menu the JMenuBar component with all the extra functionalities of the Game 
         * @param time that represents the live tracking time for the time limit
         * @param panel JPanel that is used for representing the Grid
         * @param splitPane JSplitPane is used for split the frame into sides Vertically
         * For the JSplitPane:
         * @see https://www.javatpoint.com/java-jsplitpane 
         * <p>
         * For the frame we add the functionality of the title, the menu and 
         * the splitPane with the live status and the Grid
         * <p>
         * As extra functionality we have added in all the Windows a WindowListener with JOptionPane
         * that asks and ensures the user that they want to close that Window
         * 
         * For JOptionPane:
         * @see https://www.javatpoint.com/java-joptionpane
         * 
         * <p>
         * 
         * 
         * */


        JPanel panel = new Grid(new GridLayout(gridSize, gridSize), handler);
        ClockPane time = new ClockPane();
        MenuBar menu = new MenuBar();
        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, time, panel);

        frame.setJMenuBar(menu.getMenuBar());
        frame.setContentPane(splitPane);
        frame.pack();
        frame.setVisible(true);

        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                        // Ask for confirmation before terminating the program.
                int option = JOptionPane.showConfirmDialog(
                    frame, 
                    "Are you sure you want to close the application?",
                    "Close Confirmation", 
                    JOptionPane.YES_NO_OPTION, 
                    JOptionPane.QUESTION_MESSAGE);
                if (option == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });
    }

    /**
     * This method dispose the frame of the Game
     * We use it when we want to call StartGame and we have already one constructor open. So:
     * -we want to close the current Window, so we dispose the frame of it
     * -we call the StartGame() constructor properly 
     * */
    public static void frame_dispose(){
        frame.dispose();
    }

}
